#include "MapLoader.h"

MapLoader::MapLoader()
{
    //ctor
}

MapLoader::~MapLoader()
{
    //dtor
}
