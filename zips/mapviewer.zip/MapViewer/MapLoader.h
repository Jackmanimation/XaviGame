#ifndef MAPLOADER_H
#define MAPLOADER_H


class MapLoader
{
    public:
        MapLoader();
        virtual ~MapLoader();



    protected:
    private:



};

#endif // MAPLOADER_H
